export interface IExtensionCollection<T> {
  supported: T[];
}
