export enum FileFormat {
  svg,
  png,
  jpg,
  gif,
  bmp,
  tiff,
  ico,
}
