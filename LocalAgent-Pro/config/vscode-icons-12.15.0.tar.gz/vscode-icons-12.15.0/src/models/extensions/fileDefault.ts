import { IDefaultExtension } from './defaultExtension';

export interface IFileDefault {
  file?: IDefaultExtension;
  file_light?: IDefaultExtension;
}
