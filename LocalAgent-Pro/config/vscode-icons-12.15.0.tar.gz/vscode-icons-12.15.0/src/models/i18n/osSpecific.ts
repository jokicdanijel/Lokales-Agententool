export interface IOSSpecific {
  darwin: string;
  linux: string;
  win32: string;
}
