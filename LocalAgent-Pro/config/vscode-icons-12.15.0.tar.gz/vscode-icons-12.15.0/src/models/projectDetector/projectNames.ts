export enum ProjectNames {
  ng = 'Angular',
  ngjs = 'AngularJS',
  nest = 'NestJS',
}
