export interface IVSCodeIconTheme {
  path: string;
  _watch: boolean;
}
