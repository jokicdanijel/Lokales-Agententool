export interface IVSCodeProperties {
  type: string;
  default: boolean | string;
  description: string;
}
