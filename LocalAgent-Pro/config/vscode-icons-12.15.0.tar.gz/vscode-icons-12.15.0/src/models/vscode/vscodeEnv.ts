export interface IVSCodeEnv {
  appName: string;
  language: string;
}
