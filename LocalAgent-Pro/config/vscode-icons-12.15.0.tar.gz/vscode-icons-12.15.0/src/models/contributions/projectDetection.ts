export interface IProjectDetection {
  autoReload: boolean;
  disableDetect: boolean;
}
